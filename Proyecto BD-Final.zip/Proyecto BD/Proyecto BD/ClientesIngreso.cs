﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_BD
{
    public partial class ClientesIngreso : Form
    {
        public ClientesIngreso()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Clientes clientes = new Clientes();
            clientes.Show();
            clientes.Left = this.Left;
            clientes.Top = this.Top;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OracleConnection conexion =
                new OracleConnection
                ("DATA SOURCE = ORCL; USER ID = MIUSUARIO; PASSWORD = 123;");
            conexion.Open();

            OracleCommand comando = new OracleCommand("PKG_PERSONAS.AGREGAR_PERSONAS", conexion);
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("CEDULA", textBox1.Text);
            comando.Parameters.AddWithValue("NOMBRE", textBox2.Text);
            comando.Parameters.AddWithValue("APELLIDOS", textBox3.Text);
            comando.Parameters.AddWithValue("TELEFONO", textBox4.Text);
            comando.Parameters.AddWithValue("CORREO_ELECTRONICO", textBox5.Text);
            comando.Parameters.AddWithValue("DIRECCION", textBox6.Text);
            int i = comando.ExecuteNonQuery();

            conexion.Close();

            if (i != 0)
            {
                MessageBox.Show("Datos guardados exitosamente");
            }
            this.Close();
            Clientes clientes = new Clientes();
            clientes.Show();
            clientes.Left = this.Left;
            clientes.Top = this.Top;
        }
    }
}
