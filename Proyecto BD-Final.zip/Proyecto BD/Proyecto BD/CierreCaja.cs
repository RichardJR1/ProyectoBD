﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_BD
{
    public partial class CierreCaja : Form
    {
        public CierreCaja()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OracleConnection conexion =
                new OracleConnection
                ("DATA SOURCE = ORCL; USER ID = MIUSUARIO; PASSWORD = 123;");
            conexion.Open();
            try
            {
                OracleCommand comando = new OracleCommand("PKG_VENTAS.CARGAR_COMPRAS_POR_DIA", conexion);
                comando.CommandType = System.Data.CommandType.StoredProcedure;
                comando.Parameters.Add(textBox1.Text, OracleType.VarChar).Direction = ParameterDirection.Input;
                comando.Parameters.Add("FILAS", OracleType.Cursor).Direction = ParameterDirection.Output;
                

                OracleDataAdapter adaptador = new OracleDataAdapter();

                adaptador.SelectCommand = comando;
                DataTable tabla = new DataTable();

                adaptador.Fill(tabla);
                dataGridView1.DataSource = tabla;
                conexion.Close();
            }
            catch (FormatException)
            {
                MessageBox.Show("Dato invalido, Ingrese un dato valido");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Compras compras = new Compras();
            compras.Show();
            compras.Left = this.Left;
            compras.Top = this.Top;
        }
    }
}
