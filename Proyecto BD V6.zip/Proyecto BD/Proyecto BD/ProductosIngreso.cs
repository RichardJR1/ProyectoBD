﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_BD
{
    public partial class ProductosIngreso : Form
    {
        public ProductosIngreso()
        {
            InitializeComponent();
        }

        private void ProductosIngreso_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Productos productos = new Productos();
            productos.Show();
            productos.Left = this.Left;
            productos.Top = this.Top;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OracleConnection conexion =
                new OracleConnection
                ("DATA SOURCE = ORCL; USER ID = MIUSUARIO; PASSWORD = 123;");
            conexion.Open();

            OracleCommand comando = new OracleCommand("PKG_VENTAS.AGREGAR_PRODUCTO", conexion);
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("ID_PRODUCTO", textBox1.Text);
            comando.Parameters.AddWithValue("NOMBRE", textBox2.Text);
            comando.Parameters.AddWithValue("IMP_PRODUCTO", textBox3.Text);
            comando.Parameters.AddWithValue("PRECIO_UNITARIO", textBox4.Text);
            comando.Parameters.AddWithValue("TARIFA_IMP", textBox5.Text); 
            comando.Parameters.AddWithValue("DESC_PRODUCTO", textBox6.Text); 
            comando.Parameters.AddWithValue("CATEGORIA_ID", textBox7.Text);
            comando.Parameters.AddWithValue("PROVEEDOR", textBox8.Text);
            int i = comando.ExecuteNonQuery();

            conexion.Close();

            if (i != 0)
            {
                MessageBox.Show("Datos guardados exitosamente");
            }
            this.Close();
            Productos productos = new Productos();
            productos.Show();
            productos.Left = this.Left;
            productos.Top = this.Top;

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
    
}
