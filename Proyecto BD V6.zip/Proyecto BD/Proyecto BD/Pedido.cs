﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_BD
{
    public partial class Pedido : Form
    {
        public Pedido()
        {
            InitializeComponent();
        }

        private void Pedido_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
            BebidasFrias bebidasfrias = new BebidasFrias();
            bebidasfrias.Show();
            bebidasfrias.Left = this.Left;
            bebidasfrias.Top = this.Top;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Menu menu = new Menu();
            menu.Show();
            menu.Left = this.Left;
            menu.Top = this.Top;
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OracleConnection conexion =
                new OracleConnection
                ("DATA SOURCE = ORCL; USER ID = MIUSUARIO; PASSWORD = 123;");
            conexion.Open();
           
                OracleCommand cmd = new OracleCommand("SELECT TEMPORAL FROM TEMPORAL_PEDIDO", conexion);
                OracleDataReader lector = cmd.ExecuteReader();
                while (lector.Read())
                {
                    textBox1.Text = lector.GetValue(0).ToString();
                }
                conexion.Close();
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
            BebidasCalientes bebidascalientes = new BebidasCalientes();
            bebidascalientes.Show();
            bebidascalientes.Left = this.Left;
            bebidascalientes.Top = this.Top;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
            Proteinas proteinas = new Proteinas();
            proteinas.Show();
            proteinas.Left = this.Left;
            proteinas.Top = this.Top;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
            Adicionales adicionales = new Adicionales();
            adicionales.Show();
            adicionales.Left = this.Left;
            adicionales.Top = this.Top;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            this.Close();
            Combos combos = new Combos();
            combos.Show();
            combos.Left = this.Left;
            combos.Top = this.Top;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Close();
            Postres postres = new Postres();
            postres.Show();
            postres.Left = this.Left;
            postres.Top = this.Top;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Close();
            Casados casados = new Casados();
            casados.Show();
            casados.Left = this.Left;
            casados.Top = this.Top;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            OracleConnection conexion =
                new OracleConnection
                ("DATA SOURCE = ORCL; USER ID = MIUSUARIO; PASSWORD = 123;");
            conexion.Open();

            OracleCommand comando = new OracleCommand("PKG_VENTAS.CARGAR_PEDIDO_TEMPORAL", conexion);
            comando.CommandType = System.Data.CommandType.StoredProcedure;
            comando.Parameters.Add("FILAS", OracleType.Cursor).Direction = ParameterDirection.Output;

            OracleDataAdapter adaptador = new OracleDataAdapter();

            adaptador.SelectCommand = comando;
            DataTable tabla = new DataTable();

            adaptador.Fill(tabla);
            dataGridView1.DataSource = tabla;

            OracleCommand cmd = new OracleCommand("SELECT TEMPORAL FROM TEMPORAL_PEDIDO", conexion);
            OracleDataReader lector = cmd.ExecuteReader();
            while (lector.Read())
            {
                textBox1.Text = lector.GetValue(0).ToString();
            }
            conexion.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
