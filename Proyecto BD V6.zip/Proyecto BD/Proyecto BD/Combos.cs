﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_BD
{
    public partial class Combos : Form
    {
        public Combos()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Pedido pedido = new Pedido();
            pedido.Show();
            pedido.Left = this.Left;
            pedido.Top = this.Top;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            OracleConnection conexion =
                new OracleConnection
                ("DATA SOURCE = ORCL; USER ID = MIUSUARIO; PASSWORD = 123;");
            conexion.Open();

            {
                using (OracleCommand cmd = new OracleCommand("SELECT ID_PRODUCTO,NOMBRE,PRECIO_UNITARIO FROM PRODUCTOS WHERE CATEGORIA_ID=5", conexion))
                {
                    cmd.CommandType = CommandType.Text;
                    using (OracleDataAdapter sda = new OracleDataAdapter(cmd))
                    {
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);
                            dataGridView1.DataSource = dt;
                        }
                    }
                }
            }
            conexion.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OracleConnection conexion =
                new OracleConnection
                ("DATA SOURCE = ORCL; USER ID = MIUSUARIO; PASSWORD = 123;");
            conexion.Open();
            try
            {
                OracleCommand cmd = new OracleCommand("SELECT NOMBRE,PRECIO_UNITARIO FROM PRODUCTOS WHERE ID_PRODUCTO='" + int.Parse(textBox1.Text) + "'", conexion);
                OracleDataReader lector = cmd.ExecuteReader();
                while (lector.Read())
                {
                    textBox2.Text = lector.GetValue(0).ToString();
                    textBox3.Text = lector.GetValue(1).ToString();
                }
                conexion.Close();
            }
            catch (FormatException)
            {
                MessageBox.Show("Dato invalido, Ingrese un dato valido");
            }
        }

        private void Combos_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            OracleConnection conexion =
                new OracleConnection
                ("DATA SOURCE = ORCL; USER ID = MIUSUARIO; PASSWORD = 123;");
            conexion.Open();

            OracleCommand comando = new OracleCommand("PKG_VENTAS.AGREGAR_PEDIDO", conexion);
            comando.CommandType = CommandType.StoredProcedure;
            comando.Parameters.AddWithValue("ID_PRODUCTO", textBox1.Text);
            comando.Parameters.AddWithValue("NOMBRE", textBox2.Text);
            comando.Parameters.AddWithValue("PRECIO", textBox3.Text);
            comando.Parameters.AddWithValue("CANTIDAD", textBox4.Text);
            int i = comando.ExecuteNonQuery();

            conexion.Close();

            if (i != 0)
            {
                MessageBox.Show("Producto seleccionado");
            }
            this.Close();
            Pedido pedido = new Pedido();
            pedido.Show();
            pedido.Left = this.Left;
            pedido.Top = this.Top;
        }
    }
}
