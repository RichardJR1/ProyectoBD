﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_BD
{
    public partial class ProductosIngreso : Form
    {
        public ProductosIngreso()
        {
            InitializeComponent();
        }

        private void ProductosIngreso_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Productos productos = new Productos();
            productos.Show();
            productos.Left = this.Left;
            productos.Top = this.Top;
        }
    }
}
