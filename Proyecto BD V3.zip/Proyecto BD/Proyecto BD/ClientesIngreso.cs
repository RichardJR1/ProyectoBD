﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_BD
{
    public partial class ClientesIngreso : Form
    {
        public ClientesIngreso()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Clientes clientes = new Clientes();
            clientes.Show();
            clientes.Left = this.Left;
            clientes.Top = this.Top;
        }
    }
}
