﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Proyecto_BD
{
    public partial class BebidasFrias : Form
    {
        public BebidasFrias()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
            Pedido pedido = new Pedido();
            pedido.Show();
            pedido.Left = this.Left;
            pedido.Top = this.Top;
        }
    }
}
